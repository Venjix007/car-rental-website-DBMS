import React from 'react';
import SellCarUserInput from './SellCarUserInput';

function SellCar() {
  return (
    <div>
      <div className="inline-block">
        <SellCarUserInput />
      </div>
    </div>
  );
}

export default SellCar;
